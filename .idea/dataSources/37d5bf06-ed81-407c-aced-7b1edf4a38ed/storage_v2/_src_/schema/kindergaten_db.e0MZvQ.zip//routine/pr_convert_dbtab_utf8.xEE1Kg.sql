create
    definer = root@`%` procedure pr_convert_dbtab_utf8(IN dbName varchar(100))
BEGIN

    declare stop int default 0;

    declare tabCount int default 0;

    declare strSql varchar(1000);

    declare name varchar(100);

    declare cur CURSOR FOR select table_name from information_schema.tables where table_schema=dbName;

    declare CONTINUE HANDLER FOR SQLSTATE '02000' SET stop = null;

    OPEN cur;

    FETCH cur INTO name;

    WHILE ( stop is not null) DO

        set tabCount=tabCount+1;

        set strSql = concat('alter table `',name,'` convert to character set utf8');

        set @sql1 = strSql;

        prepare stmt_p from @sql1;

        execute stmt_p;

        FETCH cur INTO name;

    END WHILE;

    CLOSE cur;

    SELECT concat('table: ', tabCount);

END;

